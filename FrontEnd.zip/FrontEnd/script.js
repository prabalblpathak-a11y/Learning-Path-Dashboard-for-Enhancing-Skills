function signup() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const pass = document.getElementById("pass").value;

  localStorage.setItem("user", JSON.stringify({ name, email, pass }));
  alert("Signup successful");
  window.location = "login.html";
}

function login() {
  const email = document.getElementById("email").value;
  const pass = document.getElementById("pass").value;

  const user = JSON.parse(localStorage.getItem("user"));

  if (user && user.email === email && user.pass === pass) {
    window.location = "index.html";
  } else {
    alert("Invalid credentials");
  }
}